package main

import (
	"fmt"
	"playground/newProject/config"
	"playground/newProject/models"
	"playground/newProject/storage/memory"
	"playground/newProject/tasks"
)

func main() {

	cfg := config.Load()
	strg := memory.NewStorage(models.FileNames{
		BranchFile:                   "data/branches.json",
		UserFile:                     "data/users.json",
		CategoryFile:                 "data/categories.json",
		ProductFile:                  "data/products.json",
		BranchProductFile:            "data/branch_products.json",
		BranchProductTransactionFile: "data/branch_pr_transaction.json",
	})
	// h := handler.NewHandler(strg, *cfg)
	// h.CreateCategory("FastFood")
	// h.GetAllBranchProductTransaction(1, 10, "", "")
	// h.CreateBranchProductTransaction("f7497e5f-ce02-452b-8ea4-d5aab1c69a1c", "b9e54f3a-7e11-4b0a-94c3-b7e27e601044", "904d377a-75e4-4dd0-a80d-9449e7b91677", "pluse", 2)
	// Tasks
	tasks := tasks.NewTasksController(strg, *cfg)

	for index, val := range tasks.TopBranchPluseMinusetransactionSorted() {
		fmt.Printf("%d %+v\n", index+1, val)
	}
	// for index, val := range tasks.TopEachBranchNestedEachCategorytransactionSorted() {
	// 	fmt.Printf("%d %s %v\n", index+1, val.BranchName, val.Categories)
	// }
	// fmt.Println(tasks.TopEachBranchNestedEachCategorytransactionSorted())
	// Category
	// h.CreateCategory("Sabzavod")
	// h.UpdateCategory("eee3d471-78c1-4aaf-8c62-4df8acbb5c1f", "Torix")
	// h.DeleteCategory("eee3d471-78c1-4aaf-8c62-4df8acbb5c1f")
	// h.GetAllCategory(1, 10)
	// h.GetCategory("ff4cb227-92d7-4a7f-83fb-4d7e3e52d4aa")
	// Product
	// h.CreateProduct("52675e16-f992-41ae-9f8d-ec2fd8c77e44", "Sok", 10500)
	// h.UpdateProduct("e4b2c0f4-b0b5-43ec-a48b-f66513e73d66", "b8301a79-a369-40b5-b518-3d68d2b43c38", "Kasha", 100_000)
	// h.GetAllProduct(1, 10)
	// h.GetProduct("e4b2c0f4-b0b5-43ec-a48b-f66513e73d66")
	// h.DeleteProduct("e4b2c0f4-b0b5-43ec-a48b-f66513e73d66")
}
